#include <stdio.h>

int main(void) {
	printf("Hello World from the patch\n");
	return 0;
}
